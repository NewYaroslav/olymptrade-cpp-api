﻿function send_data() 
{
	socket.send('[{"t":2,"e":23,"d":[{"amount":'+amount+',"dir":"'+trend+'","pair":"'+pair+'","pos":0,"source":"platform","group":"'+group+'","duration":'+time+"}]}]");
}

function getUuid(){
    return(Date.now().toString(36)+Math.random().toString(36).substr(2,12)).toUpperCase()
}


function sec() //выполняется каждую секунду
{ 
	console.log("sec: "+tick);
	tick++;
	if(is_init == false) {
		(socket=new WebSocket("wss://olymptrade.com/ds/v2")).onopen=function(){
			console.log("Соединение установлено.");
			//socket.send('[{"t":2,"e":23,"d":[{"amount":'+amount+',"dir":"'+trend+'","pair":"'+pair+'","pos":0,"source":"platform","group":"'+group+'","duration":'+time+"}]}]");
			
			// [{"t": 2,"e": 4,"uuid": "JOAHF1NK6GVW9JJV08X","d": [{"p": "GBPUSD","tf": 60}]}] 
			
			//socket.send('[{"t": 2,"e": 4,"uuid": "'+getUuid()+'","d": [{"p": "Bitcoin","tf": 60},{"p": "BCHUSD","tf": 60},{"p": "XRPUSD","tf": //60},{"p": "ETHUSD","tf": 60},{"p": "LTCBTC","tf": 60}]}]');
			
			//socket.send('[{"t": 2,"e": 4,"uuid": "'+getUuid()+'","d": [{"p": "BCHUSD","tf": 60}]}]');
			
			is_init = true;
		},
		socket.onclose=function(e){
			if(e.wasClean) {
				log("Соединение закрыто чисто");
			} else {
				console.log("Обрыв соединения");
				socket.close();
			}
			console.log("Код: "+e.code+" причина: "+e.reason);
			// перезагрузим страницу
			location.reload();
			//
			is_init = false;
		},
		socket.onmessage=function(e){
			///console.log("Получены данные "+e.data);
			//message_in = e.data;
			if(is_init_api) {
				socket_api.send(e.data);
			}
		},
		socket.onerror=function(e){
			console.log("Ошибка "+e.message);
			if(is_init) socket.close();
			// перезагрузим страницу
			location.reload();
			//
			is_init = false;
		}
	}
	if(is_init_api == false) {
		(socket_api=new WebSocket("ws://localhost:8080/echo_socket")).onopen=function(){
			console.log("Соединение API установлено.");
			is_init_api = true;
		},
		socket_api.onclose=function(e){
			if(e.wasClean) {
				console.log("Соединение API закрыто чисто");
			} else {
				console.log("Обрыв соединения API");
				socket_api.close();
			}
			console.log("API Код: "+e.code+" причина: "+e.reason);
			is_init_api = false;
		},
		socket_api.onmessage=function(e){
			///console.log("Получены данные API "+e.data);
			if(is_init) {
				socket.send(e.data);
			}
		},
		socket_api.onerror=function(e){
			console.log("Ошибка API "+e.message);
			if(is_init_api) socket_api.close();
			is_init_api = false;
		}
	}
	if(is_init_api_control == false) {
		(socket_control=new WebSocket("ws://localhost:8080/echo_control")).onopen=function(){
			console.log("Соединение API control установлено.");
			is_init_api_control = true;
		},
		socket_control.onclose=function(e){
			if(e.wasClean) {
				console.log("Соединение API control закрыто чисто");
			} else {
				console.log("Обрыв соединения API control");
				socket_control.close();
			}
			console.log("API control Код: "+e.code+" причина: "+e.reason);
			is_init_api_control = false;
		},
		socket_control.onmessage=function(e){
			///console.log("Получены данные API control "+e.data);
			var data_control = JSON.parse(e.data);
			if(data_control.cmd == 'reload_winperc') {
				console.log("Перезагружаем выплаты...");
				if(is_init) socket.close();
				is_init = false;
			} else
			if(data_control.cmd == 'hist') {
				console.log("Загружаем историю...");
				var pair_name = data_control.pair;
				var json_upload = '{"pair":"'+data_control.pair+'","size":'+data_control.size+',"from":'+data_control.from+',"to":'+data_control.to+',"limit":'+data_control.limit+'}';
				console.log("json_upload "+json_upload);
				var r = new XMLHttpRequest;
				r.open("POST","https://api.olymptrade.com/v3/cabinet/candle-history",true);
				r.withCredentials = true;
				r.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
				r.setRequestHeader('Accept', 'application/json, text/plain, */*');
				r.setRequestHeader('X-Request-Type', 'Api-Request');
				r.setRequestHeader('X-Request-Project', 'bo');
				r.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
				r.send(json_upload);
				r.onreadystatechange=function() {
					if(4==r.readyState&&200==r.status) {
						socket_control.send(r.responseText);
					}
				};
			} else
			if(data_control.cmd == 'account') {
				console.log("Загружаем данные аккаунта...");
				var r = new XMLHttpRequest;
				r.open("GET","https://olymptrade.com/platform/state?717374873",true);
				r.withCredentials = true;
				r.setRequestHeader('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8');
				r.setRequestHeader('Upgrade-Insecure-Requests', '1');
				r.send();
				r.onreadystatechange=function() {
					if(4==r.readyState&&200==r.status) {
						///console.log("Данные аккаунта "+r.responseText);
						socket_control.send(r.responseText);
					}
				};
			} else
			if(data_control.cmd == 'init_stream_quotes') {
				var str = '[{"t": 2,"e": 4,"uuid": "'+getUuid()+'","d": [';
				var symbols_size = data_control.symbols_size;
				for(var i = 0; i < symbols_size; ++i) {
					str += '{"p": "'+data_control.symbols[i]+'","tf": '+data_control.size+'}';
					if(i + 1 < symbols_size) str += ',';
				}
				str += ']}]';
				socket.send(str);
			}
		},
		socket_control.onerror=function(e){
			console.log("Ошибка API control "+e.message);
			socket_control.close();
			is_init_api_control = false;
		}
	}
}			 	

setInterval(sec, 1000);// запускать функцию каждую секунду

var tick = 0;
var is_init = false;
var is_init_api = false;
var is_init_api_control = false;
var is_upload_hist = false;
var socket;
var socket_api;
var socket_control;
var amount = 30;
var trend="down";
var pair="EURUSD";
var group="demo";
var time=60;