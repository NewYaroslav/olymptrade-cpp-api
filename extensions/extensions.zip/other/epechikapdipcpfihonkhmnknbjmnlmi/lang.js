var lang_ru = {
    code: 'ru',
    top: {
        button: {
            open: 'Открыть робота',
            close: 'Свернуть робота'
        },
    },
    body: {
        change_acc: {
            title: 'Выбор счета',
            real_acc: 'Реальный счёт',
            demo_acc: 'Учебный счёт',
            faq: {
                info: 'Выберите счет, на котором будет торговать робот.',
                warn: 'Торговля роботом на реальном счету доступна только после активации робота.'
            }
        },
        start_robot: {
            title: 'Запуск робота',
            button: 'Начать торговлю'
        },
        stop_robot: {
            title: 'Остановка робота',
            button: 'Остановить торговлю'
        },
        main_param: {
            title: 'Основные параметры',
            amount: 'Начальная ставка',
            time: 'Время',
            asset: 'Торговый актив',
            times: {
                min1: '1 мин.',
                min1_tag: 'min1',
                min5: '5 мин.',
                min5_tag: 'min5',
                min10: '10 мин.',
                min10_tag: 'min10',
                min15: '15 мин.',
                min15_tag: 'min15',
            },
            faq: {
                amount_info: 'cтавка, которую делает робот на первом шаге работы алгоритма.',
                amount_rec: 'Рекомендуемое значение — 30₽ / 1$ / 1€ (в зависимости от валюты счёта).',
                time_info: 'время, на которое робот делает ставки.',
                time_rec: 'Рекомендуемое значение — 1 мин.',
                asset_info: 'актив, на котором торгует робот.',
                asset_rec: 'Рекомендуемое значение — актив с высоким процентом выигрыша.'
            }
        },
        strategy: {
            title: 'Торговые стратегии',
            str1: 'Выигрыш за 1 период времени',
            str2: 'Выигрыш каждый период времени',
            faq: {
                str1_info: 'При выигрыше следущую ставку робот принимает равной начальной ставки, в противном случае последующие ставки рассчитываются таким образом, чтобы суммой выигрыша покрыть все предыдущие проигрыши и заработать сумму равную выигрышу от начальной ставки.',
                str1_rec: 'Рекомендуемое значение депозита — от 4000 до 40000₽ (от 100 до 1000 $/€).',
                str2_info: 'При выигрыше следущую ставку робот принимает равной начальной ставки, в противном случае последующие ставки рассчитываются таким образом, чтобы суммой выигрыша покрыть все предыдущие проигрыши и заработать сумму равную выигрышу от каждой ставки.',
                str2_rec: 'Рекомендуемое значение депозита — от 40000₽ (от 1000 $/€).'
            }
        },
        signals: {
            title: 'Торговля по сигналам',
            check: 'Использовать сигналы с сервера',
            faq: {
                title: 'Использовать сигналы с сервера аналитики OlympBot',
                info: 'При установке данного параметра робот будет получать сигналы от нашего сервера аналитики.',
                rec: 'Рекомендуется включать данный параметр. Он повышает точность ставок до 50%.',
                warn: 'Торговля роботом по сигналам доступна только после активации аккаунта. Вы можете активировать свой аккаунт и протестировать торговлю по сигналам на учебном счёте. Это сделано для снижения нагрузки на сервера OlympBot.'
            }
        },
        signals_plus: {
            title: 'Торговля по сигналам',
            button: 'Активировать торговлю по сигналам',
            text: 'Повышает точность ставок до 50%'
        },
        add_param: {
            title: 'Дополнительные параметры',
            balance: 'Макс. баланс',
            auto: 'Автоматический выбор лучшего актива',
            faq: {
                balance_info: 'баланс, при достяжении которого робот остановит свою работу.',
                balance_warn: 'Без активации робот будет останавливаться как только заработает 1000₽ / 20$ / 20€ (в зависимости от валюты счёта). Вы можете запустить его заново, либо пройти активацию и снять данное ограничение.',
                auto_info: 'Робот будет выбирать наиболее выгодный актив автоматически.',
                auto_rec: 'Рекомендуется включать данный параметр.'
            }
        },
        real_activate: {
            title: 'Торговля на реальном счете',
            activate_text: 'Для торговли на реальном счете требуется активация робота.',
            activate_button: 'Активировать робота',
            demo_text: 'Без активации вы можете протестировать робота на учебном счете.',
            demo_button: 'Перейти на учебный счёт'
        },
        faq_button: 'Справка',
        faq_title: 'Инструкция по работе с роботом',
        buttons: {
            close: 'Закрыть',
            ok: 'ОК'
        }
    },
    activate: {
        title: 'Активация робота',
        info: 'Активация позволяет снять ограничение по заработку, открыть возможность торговли по сигналам и на реальном счёте. Активация состоит из 2х шагов, которые надо выполнить полседовательно.',
        step1: {
            title: 'Шаг #1. Зарегистрировать аккаунт OlympTrade через систему OlympBot.',
            text1: 'Для активации робота необходимо иметь аккаунт, зарегистрированный через форму ниже:',
            text2: 'Активировать робота на ранее зарегистрированном аккаунте нельзя.',
            button: 'Показать форму регистрации'
        },
        step2: {
            title: 'Шаг #2. Пополните счёт на сумму от 4000₽ (от 100 $/€).',
            text1: 'Пополните счёт на сумму от 100 $/€.<br>Для рублевых счетов минимальная сумма пополнения составляет 4000₽.',
            text2: 'Сумма депозита обусловлена стратегией, используемой в роботе: необходимо иметь запас для покрытия в случае неудачной сделки.',
            button: 'Пополнить счёт'
        },
        already: {
            title: 'Ваш OlympBot уже активирован',
            info: 'Вы выполнили условия активации и можете использовать весь функционал робота.'
        }
    },
    alert: {
        stop_user: 'Робот остановлен принудительно',
        filter_balance: 'Достигнут фильтр максимального баланса (дополнительные параметры)',
        robot_start: 'Робот запущен',
        robot_start_info: 'Вы можете свернуть вкладку с платформой.',
        robot_start_filter1: 'Робот остановится, как только на счету будет',
        robot_start_filter2: 'Активируйте робота, чтобы снять ограничение по доходу, либо запустите его заново.',
        robot_stop: 'Робот остановлен'
    },
    process: {
        signal_search: 'Поиск сигналов',
        signal_search_info: 'Идет поиск сигналов...',
        current: 'Текущая ставка',
        show: 'Показать'
    }
};

var lang_en = {
    code: 'en',
    top: {
        button: {
            open: 'Open the robot',
            close: 'Close the robot'
        },
    },
    body: {
        change_acc: {
            title: 'Account selection',
            real_acc: 'Live account',
            demo_acc: 'Demo account',
            faq: {
                info: 'Select an account on which the robot will trade.',
                warn: 'Trading with a robot on a real account is available only after its activation.'
            }
        },
        start_robot: {
            title: 'Start the robot',
            button: 'Start trading'
        },
        stop_robot: {
            title: 'Stop the robot',
            button: 'Stop trading'
        },
        main_param: {
            title: 'Trading options',
            amount: 'Initial amount',
            time: 'Time',
            asset: 'Trading asset',
            times: {
                min1: '1 min',
                min1_tag: 'min1',
                min5: '5 min',
                min5_tag: 'min5',
                min10: '10 min',
                min10_tag: 'min10',
                min15: '15 min',
                min15_tag: 'min15',
            },
            faq: {
                amount_info: 'The trade amount at which the robot will begin to trade each lap.',
                amount_rec: 'The recommended value is $/€ 1.',
                time_info: 'The trade period.',
                time_rec: 'The recommended value is 1 min.',
                asset_info: 'The asset on which the robot will trade.',
                asset_rec: 'The recommended asset is the one with a high winning percentage (>70%).'
            }
        },
        strategy: {
            title: 'Trading strategies',
            str1: 'Win every round (Optimal)',
            str2: 'Win every bet (Aggressive)',
            faq: {
                str1_info: 'When winning the next bet, the robot assumes equal to the initial bet. Otherwise subsequent bets are calculated so that the win amount covers all previous losses and earns an amount equal to the win from the initial bet.',
                str1_rec: 'Recommended strategy with a balance of 100 to 1000 dollars or euro.',
                str2_info: 'When winning the next bet, the robot assumes equal to the initial bet. Otherwise subsequent bets are calculated in such a way that the win amount to cover all previous losses and earn an amount equal to the win from each bet.',
                str2_rec: 'The strategy is recommended for a balance of 1000 dollars or euro.'
            }
        },
        signals: {
            title: 'Signal trading',
            check: 'Follow trading signals',
            faq: {
                title: 'Use signals from the analytics server OlympBot',
                info: 'With this feature, the robot will receive signals from our analytics server.',
                rec: 'It is recommended to enable this option. It improves the accuracy of rates up to 50%.',
                warn: 'Signals trading is available only after account activation. You can activate your account and test trading on signals on a demo account. This is done to reduce the load on the OlympBot server.'
            }
        },
        signals_plus: {
            title: 'Signal trading',
            button: 'Follow trading signals',
            text: 'Increases bet accuracy up to 50%'
        },
        add_param: {
            title: 'Extra options',
            balance: 'Max balance',
            auto: 'Auto selection of asset',
            faq: {
                balance_info: 'The balance at which the robot will stop its work.',
                balance_warn: 'Without activation, the robot will stop as soon as it earns $/€ 20. You can start it again, or go through activation and remove this restriction.',
                auto_info: 'The robot will select the most profitable asset automatically.',
                auto_rec: 'It is recommended to enable this option.'
            }
        },
        real_activate: {
            title: 'Trading on a live account',
            activate_text: 'For trading on a live account, robot activation is required.',
            activate_button: 'Activate the robot',
            demo_text: 'Without activation, you can test the robot on a demo account.',
            demo_button: 'Go to the demo account'
        },
        faq_button: 'Instruction',
        faq_title: 'Robot instruction',
        buttons: {
            close: 'Close',
            ok: 'OK'
        }
    },
    activate: {
        title: 'Robot activation',
        info: 'Activation allows you to remove the limit on earnings, open the possibility of trading on signals and the real account. Activation consists of 2 steps that must be completed halfway.',
        step1: {
            title: 'Step 1. Register an OlympTrade account through the OlympBot system.',
            text1: 'To activate the robot, you need to have an OlympTrade account registered by the form below:',
            text2: 'It is impossible to activate the robot on a previously registered account.',
            button: 'Show registration form'
        },
        step2: {
            title: 'Step 2. Deposit $/€ 100 or more',
            text1: 'Deposit $/€ 100 or more.',
            text2: 'The amount of the deposit is determined by the strategy used in the robot: it is necessary to have a margin to cover in case of a failed transaction.',
            button: 'Deposit'
        },
        already: {
            title: 'Your OlympBot is already activated',
            info: 'You have completed the activation conditions and can use all the functionality of the robot.'
        }
    },
    alert: {
        stop_user: 'You canceled a robot bet',
        filter_balance: 'Maximum balance filter reached (Extra options)',
        robot_start: 'The robot is running',
        robot_start_info: 'You can minimize the tab with the platform.',
        robot_start_filter1: 'The robot will stop as soon as the balance is',
        robot_start_filter2: 'Activate the robot to remove the income limit, or re-launch it.',
        robot_stop: 'Robot stopped'
    },
    process: {
        signal_search: 'Signal search',
        signal_search_info: 'Signal search in progress ...',
        current: 'Current bet',
        show: 'Show'
    }
};

var lang_es = {
    code: 'es',
    top: {
        button: {
            open: 'Abrir el robot',
            close: 'Cerrar el robot'
        }
    },
    body: {
        change_acc: {
            title: 'Selección de cuenta',
            real_acc: 'Cuenta Real',
            demo_acc: 'Cuenta de demo',
            faq: {
                info: 'Seleccione una cuenta en la cual el robot comerciará.',
                warn: 'El comercio con un robot en una cuenta real está disponible solo después de su activación.'
            }
        },
        start_robot: {
            title: 'Activar el robot',
            button: 'Comenzar a negociar'
        },
        stop_robot: {
            title: 'Detener al robot',
            button: 'Dejar de comerciar'
        },
        main_param: {
            title: 'Opciones de operaciones bursátiles',
            amount: 'Cantidad inicial',
            time: 'Tiempo',
            asset: 'Activo comercial',
            times: {
                min1: '1 min',
                min1_tag: 'min1',
                min5: '5 min',
                min5_tag: 'min5',
                min10: '10 min',
                min10_tag: 'min10',
                min15: '15 min',
                min15_tag: 'min15'
            },
            faq: {
                amount_info: 'La cantidad comercial en la que el robot comenzará a comerciar en cada vuelta.',
                amount_rec: 'El valor recomendado es de 1 $/€.',
                time_info: 'El período comercial.',
                time_rec: 'El valor recomendado es de 1 min.',
                asset_info: 'El activo con el que el robot comerciará.',
                asset_rec: 'El activo recomendado es el que tiene un alto porcentaje de ganancias (mayor al 70 %).'
            }
        },
        strategy: {
            title: 'Estrategias comerciales',
            str1: 'Gana cada ronda (óptimo)',
            str2: 'Gana cada apuesta (agresivo)',
            faq: {
                str1_info: 'Al ganar la próxima apuesta, el robot asume lo mismo que la apuesta inicial. De lo contrario, las apuestas subsiguientes se calculan de manera que la cantidad ganada cubra todas las pérdidas anteriores y gane una cantidad igual a la ganancia de la apuesta inicial.',
                str1_rec: 'Estrategia recomendada con un saldo de 100 a 1000 $ o €.',
                str2_info: 'Al ganar la próxima apuesta, el robot asume lo mismo que la apuesta inicial. De lo contrario, las apuestas subsiguientes se calculan de tal manera que la cantidad de ganancia cubra todas las pérdidas anteriores y obtenga una cantidad igual a la ganancia de cada apuesta.',
                str2_rec: 'La estrategia se recomienda para un saldo de 1000 $ o €.'
            }
        },
        signals: {
            title: 'Señal de comercio',
            check: 'Seguir las señales de comercio',
            faq: {
                title: 'Utilizar señales del servidor de análisis de OlympBot',
                info: 'Con esta función, el robot recibirá señales de nuestro servidor de análisis.',
                rec: 'Se recomienda habilitar esta opción. Mejora la precisión de las tasas hasta un 50 %.',
                warn: 'El comercio de señales solo está disponible después de la activación de la cuenta. Puede activar su cuenta y probar el comercio de señales en una cuenta de demostración. Esto se hace para reducir la carga en el servidor de OlympBot.'
            }
        },
        signals_plus: {
            title: 'Señal de comercio',
            button: 'Seguir las señales de comercio',
            text: 'Aumenta la precisión de la apuesta hasta un 50 %.'
        },
        add_param: {
            title: 'Opciones extra',
            balance: 'Saldo máximo',
            auto: 'Selección automática de activos',
            faq: {
                balance_info: 'El saldo en el que el robot se detendrá.',
                balance_warn: 'Sin activación, el robot se detendrá tan pronto como gane 20 $/€. Puede volver a iniciarlo o pasar por la activación y eliminar esta restricción.',
                auto_info: 'El robot seleccionará automáticamente el activo más rentable.',
                auto_rec: 'Se recomienda habilitar esta opción.'
            }
        },
        real_activate: {
            title: 'Operando en una cuenta real',
            activate_text: 'Para operar en una cuenta real, se requiere la activación del robot.',
            activate_button: 'Activar el robot',
            demo_text: 'Sin la activación, puede probar el robot en una cuenta de demostración.',
            demo_button: 'Ir a la cuenta de demostración'
        },
        faq_button: 'Instrucción',
        faq_title: 'Instrucción de robot',
        buttons: {
            close: 'Cerrar',
            ok: 'De acuerdo'
        }
    },
    activate: {
        title: 'Activación de robot',
        info: 'La activación le permite eliminar el límite de ganancias, abrir la posibilidad de negociar con las señales y la cuenta real. La activación consiste en 2 pasos que deben completarse a medio camino.',
        step1: {
            title: 'Paso 1: Registre una cuenta de OlympTrade a través del sistema de OlympBot.',
            text1: 'Para activar el robot, debe tener una cuenta de OlympTrade registrada en el siguiente formulario:',
            text2: 'Es imposible activar el robot en una cuenta previamente registrada.',
            button: 'Mostrar formulario de OlympTrade registrada'
        },
        step2: {
            title: 'Paso 2: Depositar 100 $/€ o más',
            text1: 'Depositar 100 $/€ o más',
            text2: 'La cantidad del depósito está determinada por la estrategia utilizada en el robot: es necesario tener un margen para cubrir casos de transacciones fallidas.',
            button: 'Depositar'
        },
        already: {
            title: 'Tu OlympBot ya está activado',
            info: 'Ha completado las condiciones de activación y puede utilizar toda la funcionalidad del robot.'
        }
    },
    alert: {
        stop_user: 'Ha cancelado una apuesta de robot',
        filter_balance: 'Se alcanzó el filtro de saldo máximo (opciones extra)',
        robot_start: 'El robot esta funcionando',
        robot_start_info: 'Puede minimizar la pestaña con la plataforma.',
        robot_start_filter1: 'El robot se detendrá tan pronto como el saldo sea',
        robot_start_filter2: 'Active el robot para eliminar el límite de ingresos o vuelva a iniciarlo.',
        robot_stop: 'Robot detenido'
    },
    process: {
        signal_search: 'Búsqueda de señales',
        signal_search_info: 'Búsqueda de señales en curso...',
        current: 'Apuesta actual',
        show: 'Mostrar'
    }
};

var lang_tr = {
    code: 'tr',
    top: {
        button: {
            open: 'Robotu aç',
            close: 'Robotu kapat'
        }
    },
    body: {
        change_acc: {
            title: 'Hesap seçimi',
            real_acc: 'Gerçek hesap',
            demo_acc: 'Deneme hesabı',
            faq: {
                info: 'Robotun alışveriş yapacağı bir hesap seçin.',
                warn: 'Bir robotla gerçek bir hesap üzerinden alışveriş yapmak ancak aktive edildikten sonra mümkündür.'
            }
        },
        start_robot: {
            title: 'Robotu başlat',
            button: 'Alışverişe başla'
        },
        stop_robot: {
            title: 'Robotu durdur',
            button: 'Alışverişi durdur'
        },
        main_param: {
            title: 'Alışveriş seçenekleri',
            amount: 'Başlangıç ​​miktarı',
            time: 'Zaman',
            asset: 'Ticari varlık',
            times: {
                min1: '1 dak.',
                min1_tag: 'min1',
                min5: '5 dak.',
                min5_tag: 'min5',
                min10: '10 dak.',
                min10_tag: 'min10',
                min15: '15 dak.',
                min15_tag: 'min15'
            },
            faq: {
                amount_info: 'Robotun her turda alışveriş yapmaya başlayacağı ticari miktar.',
                amount_rec: 'Önerilen değer 1 Dolar/Euro\'dur.',
                time_info: 'Alışveriş dönemi.',
                time_rec: 'Önerilen değer asgari 1\'dir .',
                asset_info: 'Robotun alım satım yapacağı varlık.',
                asset_rec: 'Önerilen varlık kazanma yüzdesi yüksek (&gt;% 70) olandır.'
            }
        },
        strategy: {
            title: 'Alışveriş stratejileri',
            str1: 'Her raundu kazan (Optimal)',
            str2: 'Her bahsi kazan (Agresif)',
            faq: {
                str1_info: 'Bir sonraki bahis kazanıldığı zaman, robot ilk bahise eş olarak varsayar. Aksi takdirde sonraki bahisler, kazanılan tutar önceki tüm kayıpları kapsasın ve ilk bahisten itibaren kazanılana eş miktarda kazanılsın diye hesaplanır.',
                str1_rec: '100 ila 1000 dolar veya euroluk bir bakiyeyle önerilen strateji.',
                str2_info: 'Bir sonraki bahis kazanıldığı zaman, robot ilk bahise eş olarak varsayar. Aksi takdirde sonraki bahisler, kazanılan tutar önceki tüm kayıpları karşılayacak ve her bahisten kazanılan paraya eşit miktarda kazanacak şekilde hesaplanır.',
                str2_rec: 'Strateji 1000 dolar veya euroluk bir bakiye için önerilir.'
            }
        },
        signals: {
            title: 'Sinyal alışverişi',
            check: 'Alışveriş sinyallerini takip et',
            faq: {
                title: 'Mantıksal analiz sunucusu OlympBot\'tan gelen sinyalleri kullan',
                info: 'Bu özellik sayesinde robot, mantıksal analiz sunucumuzdan sinyaller alacaktır.',
                rec: 'Bu seçeneğin etkinleştirilmesi önerilir. Fiyat listelerinin %50\'ye kadar doğruluğunu artırır.',
                warn: 'Sinyal alışverişi yalnızca hesap etkinleştirme sonrası kullanılabilir. Hesabınızı etkinleştirebilir ve bir demo hesapla sinyaller üzerinden alışverişi test edebilirsiniz. Bu, OlympBot sunucusundaki yükü azaltmak için yapılır.'
            }
        },
        signals_plus: {
            title: 'Sinyal alışverişi',
            button: 'Alışveriş sinyallerini takip et',
            text: '%50\'ye kadar bahis doğruluğunu arttırır'
        },
        add_param: {
            title: 'Ekstra seçenekler',
            balance: 'Maksimum bakiye',
            auto: 'Otomatik varlık seçimi',
            faq: {
                balance_info: 'Robotun çalışmasını durduracağı bakiye.',
                balance_warn: 'Aktivasyon olmadan, robot 20 Dolar/Euro kazanır kazanmaz duracaktır. Tekrar başlatabilir veya aktivasyonu gerçekleştirip bu kısıtlamayı kaldırabilirsiniz.',
                auto_info: 'Robot en karlı varlığı otomatik olarak seçecektir.',
                auto_rec: 'Bu seçeneğin etkinleştirilmesi önerilir.'
            }
        },
        real_activate: {
            title: 'Kullanılan hesap üzerinden alışveriş yapma',
            activate_text: 'Kullanılan hesap üzerinden alışveriş yapmak için robot aktivasyonu gereklidir.',
            activate_button: 'Robotu aktive et',
            demo_text: 'Aktivasyon olmadan, robotu bir demo hesabında test edebilirsiniz.',
            demo_button: 'Demo hesaba git'
        },
        faq_button: 'Talimat',
        faq_title: 'Robot talimatı',
        buttons: {
            close: 'Kapat',
            ok: 'Tamam'
        }
    },
    activate: {
        title: 'Robot aktivasyonu',
        info: 'Aktivasyon, kazanç sınırını kaldırmanıza, sinyaller ve gerçek hesapları üzerinden alışveriş yapma olanağını tanır. Aktivasyon işi bitirmeden tamamlanması gereken 2 adımdan oluşur.',
        step1: {
            title: 'Adım 1. OlympBot sistemi üzerinden bir OlympTrade hesabına kaydolun.',
            text1: 'Robotu aktive etmek için, aşağıdaki formda kayıtlı bir OlympTrade hesabınız olmalıdır:',
            text2: 'Robotu daha önce kayıtlı bir hesapta aktive etmek mümkün değildir.',
            button: 'Kayıt formunu göster'
        },
        step2: {
            title: 'Adım 2. 100 Dolar/Euro veya daha fazla depozito verin',
            text1: '100 Dolar/Euro veya daha fazla',
            text2: 'Depozito miktarı, robotta kullanılan strateji ile belirlenir: başarısız bir işlem durumunda karşılaması için marj bulunması gerekir.',
            button: 'Depozito'
        },
        already: {
            title: 'OlympBot\'unuz zaten aktive edilmiş',
            info: 'Aktivasyon koşullarını tamamladınız ve robotun tüm fonksiyonlarını kullanabilirsiniz.'
        }
    },
    alert: {
        stop_user: 'Bir robot bahsini iptal ettiniz',
        filter_balance: 'Maksimum bakiye filtresine ulaşıldı (Ekstra seçenekler)',
        robot_start: 'Robot çalışıyor',
        robot_start_info: 'Sekmeyi platformla küçültebilirsiniz.',
        robot_start_filter1: 'Robot, bakiye şu değere ulaşır ulaşmaz duracaktır',
        robot_start_filter2: 'Gelir sınırını kaldırmak için robotu aktive edin veya tekrar başlatın.',
        robot_stop: 'Robot durdu'
    },
    process: {
        signal_search: 'Sinyal arama',
        signal_search_info: 'Sinyal arama devam ediyor...',
        current: 'Mevcut bahis',
        show: 'Göster'
    }
};

var lang_id = {
    code: 'id',
    top: {
        button: {
            open: 'Buka robot',
            close: 'Tutup robot'
        }
    },
    body: {
        change_acc: {
            title: 'Pilih akun',
            real_acc: 'Akun real',
            demo_acc: 'Akun demo',
            faq: {
                info: 'Pilih akun yang akan digunakan robot untuk trade.',
                warn: 'Trading dengan robot di akun sungguhan hanya tersedia setelah diaktivasi.'
            }
        },
        start_robot: {
            title: 'Mulai robot',
            button: 'Mulai trading'
        },
        stop_robot: {
            title: 'Stop robot',
            button: 'Stop trading'
        },
        main_param: {
            title: 'Opsi trading',
            amount: 'Nominal awal',
            time: 'Waktu',
            asset: 'Aset trading',
            times: {
                min1: '1 min.',
                min1_tag: 'min1',
                min5: '5 min.',
                min5_tag: 'min5',
                min10: '10 min.',
                min10_tag: 'min10',
                min15: '15 min.',
                min15_tag: 'min15'
            },
            faq: {
                amount_info: 'Nominal trade di mana robot akan mulai trading di tiap putaran.',
                amount_rec: 'Nilai yang disarankan $/€ 1.',
                time_info: 'Periode trade.',
                time_rec: 'Nilai yang disarankan 1 mnt.',
                asset_info: 'Aset di mana robot akan melakukan trade.',
                asset_rec: 'Aset yang disarankan adalah yang memiliki persentase tinggi untuk menang (70%).'
            }
        },
        strategy: {
            title: 'Strategi trading',
            str1: 'Menangkan setiap ronde (Optimal)',
            str2: 'Menangkan setiap bet (Agresif)',
            faq: {
                str1_info: 'Saat memenangkan bet selanjutnya, robot menganggap setara dengan bet awal. Jika tidak, maka bet berikutnya dikalkulasi agar nominal menang menutupi semua kekalahan sebelumnya dan memperoleh nominal yang setara dengan kemenangan dari bet awal.',
                str1_rec: 'Strategi yang disarankan dengan saldo antara 100 sampai 1000 dolar atau euro.',
                str2_info: 'Saat memenangkan bet selanjutnya, robot menganggap setara dengan bet awal. Jika tidak, maka bet berikutnya dikalkulasi sedemikian rupa agar nominal menang menutupi semua kekalahan sebelumnya dan memperoleh nominal yang setara dengan kemenangan setiap bet.',
                str2_rec: 'Strategi ini disarankan untuk saldo sebesar 1000 dolar atau euro.'
            }
        },
        signals: {
            title: 'Signal trading',
            check: 'Ikuti sinyal trading',
            faq: {
                title: 'Gunakan sinyal dari server analitik OlympBot',
                info: 'Dengan fitur ini, robot akan menerima sinyal dari server analitik kami.',
                rec: 'Disarankan mengaktifkan opsi ini. Ini akan meningkatkan keakuratan suku bunga hingga 50%.',
                warn: 'Signal trading tersedia hanya setelah akun diaktivasi. Anda dapat mengaktivasi akun dan mengetes trading berdasarkan sinyal di akun demo. Ini dilakukan guna mengurangi muatan di server OlympBot.'
            }
        },
        signals_plus: {
            title: 'Signal trading',
            button: 'Ikuti sinyal trading',
            text: 'Meningkatkan keakuratan bet hingga 50%'
        },
        add_param: {
            title: 'Opsi tambahan',
            balance: 'Saldo maks',
            auto: 'Pilih otomatis aset',
            faq: {
                balance_info: 'Saldo di mana robot akan menghentikan kinerjanya.',
                balance_warn: 'Tanpa aktivasi, robot akan berhenti segera setelah menghasilkan $/€ 20. Anda dapat memulainya lagi, atau lakukan aktivasi dan hapus batasan ini. ',
                auto_info: 'Robot akan memilih aset yang paling menguntungkan secara otomatis.',
                auto_rec: 'Disarankan mengaktifkan opsi ini.'
            }
        },
        real_activate: {
            title: 'Trading di akun real',
            activate_text: 'Untuk trading di akun real, diperlukan aktivasi robot.',
            activate_button: 'Aktifkan robot',
            demo_text: 'Tanpa aktivasi, Anda dapat mengetes robot di akun demo.',
            demo_button: 'Ke akun demo'
        },
        faq_button: 'Instruksi',
        faq_title: 'Instruksi robot',
        buttons: {
            close: 'Tutup',
            ok: 'Oke'
        }
    },
    activate: {
        title: 'Aktivasi robot',
        info: 'Aktivasi mengizinkan Anda menghapus batasan untuk pemasukan, membuka peluang trading berdasarkan sinyal dan akun sungguhan. Aktivasi terdiri dari 2 langkah yang harus diselesaikan di tengah jalan.',
        step1: {
            title: 'Langkah 1. Daftarkan akun OlympTrade melalui sistem OlympBot.',
            text1: 'Untuk mengaktifkan robot, Anda perlu mendaftarkan akun OlympTrade melalui formulir di bawah:',
            text2: 'Anda tidak dapat mengaktifkan robot pada akun yang sudah terdaftar sebelumnya.',
            button: 'Tampilkan formulir'
        },
        step2: {
            title: 'Langkah 2. Depositkan $/€ 100 atau lebih',
            text1: 'Depositkan $/€ 100 atau lebih.',
            text2: 'Nominal deposit ditentukan oleh strategi yang digunakan dalam robot: penting untuk memiliki margin guna menjaga apabila terjadi transaksi gagal.',
            button: 'Deposit'
        },
        already: {
            title: 'OlympBot Anda sudah diaktivasi',
            info: 'Anda sudah memenuhi syarat aktivasi dan dapat menggunakan semua fungsi yang dimiliki robot.'
        }
    },
    alert: {
        stop_user: 'Anda membatalkan bet robot',
        filter_balance: 'Filter saldo maksimal tercapai (Opsi tambahan)',
        robot_start: 'Robot sedang berjalan',
        robot_start_info: 'Anda dapat mengecilkan tab dengan platform.',
        robot_start_filter1: 'Robot akan berhenti segera setelah saldo',
        robot_start_filter2: 'Aktifkan robot untuk menghapus batasan pemasukan, atau luncurkan ulang.',
        robot_stop: 'Robot berhenti'
    },
    process: {
        signal_search: 'Pencarian sinyal',
        signal_search_info: 'Pencarian sinyal sedang berjalan...',
        current: 'Bet saat ini',
        show: 'Tampilkan'
    }
};

var lang_zh = {
    code: 'zh',
    top: {
        button: {
            open: '打开机器人',
            close: '关闭机器人'
        }
    },
    body: {
        change_acc: {
            title: '账户选择',
            real_acc: '真实账户',
            demo_acc: '模拟账户',
            faq: {
                info: '选择使用机器人交易的账户。',
                warn: '只有在激活后，才能在真实账户上使用机器人进行交易。'
            }
        },
        start_robot: {
            title: '启动机器人',
            button: '开始交易'
        },
        stop_robot: {
            title: '停止机器人',
            button: '停止交易'
        },
        main_param: {
            title: '交易期权',
            amount: '初始金额',
            time: '时间',
            asset: '交易资产',
            times: {
                min1: '1 最低',
                min1_tag: 'min1',
                min5: '5 最低',
                min5_tag: 'min5',
                min10: '10 最低',
                min10_tag: 'min10',
                min15: '15 最低',
                min15_tag: 'min15'
            },
            faq: {
                amount_info: '机器人开始每圈交易的交易金额。',
                amount_rec: '建议值为 1 美元或欧元。',
                time_info: '交易周期。',
                time_rec: '推荐值为 1 分钟。',
                asset_info: '机器人交易的资产。',
                asset_rec: '推荐的资产是中标率高( &gt;70% )的资产。'
            }
        },
        strategy: {
            title: '交易策略',
            str1: '赢每一轮(最佳)',
            str2: '赢每一注(激进)',
            faq: {
                str1_info: '当赢得下一个赌注时，机器人假设等于初始赌注。否则，随后的赌注会被计算出来，这样赢的金额就可以弥补之前的所有损失，并从最初的赌注中获得与赢的金额相等的金额。',
                str1_rec: '建议的策略，余额保持 100 至 1000 美元或欧元。',
                str2_info: '当赢得下一个赌注时，机器人假设等于初始赌注。否则，后续下注的计算方式应确保赢款足以弥补之前的所有损失，并从每次下注中赚取与赢款相等的金额。',
                str2_rec: '该策略建议余额为1000美元或欧元。'
            }
        },
        signals: {
            title: '信号交易',
            check: '跟随交易信号',
            faq: {
                title: '使用来自分析服务器 OlympBot 的信号',
                info: '通过这个功能，机器人将从我们的分析服务器接收信号。',
                rec: '建议启用此选项。它提高了 50 % 的准确率。',
                warn: '只有在账户激活后，信号交易才可用。你可以激活你的账户，测试演示账户上的信号交易。这样做是为了减轻 OlympBot 服务器上的负载。'
            }
        },
        signals_plus: {
            title: '信号交易',
            button: '跟随交易信号',
            text: '提高精确度高达 50 %'
        },
        add_param: {
            title: '其他选项',
            balance: '最大余额',
            auto: '资产的自动选择',
            faq: {
                balance_info: '机器人停止工作的平衡点。',
                balance_warn: '如果不激活，机器人一赚到 20 美元就会停止工作。您可以重新启动它，或者进行激活删除此限制。',
                auto_info: '机器人将自动选择收益最高的资产。',
                auto_rec: '建议启用此选项。'
            }
        },
        real_activate: {
            title: '在真实账户上交易',
            activate_text: '对于真实账户交易，需要激活机器人。',
            activate_button: '激活机器人',
            demo_text: '如果没有激活，你可以用演示帐户测试机器人。',
            demo_button: '转到演示帐户'
        },
        faq_button: '指令',
        faq_title: '机器人指令',
        buttons: {
            close: '关闭',
            ok: '好的'
        }
    },
    activate: {
        title: '机器人激活 ',
        info: '激活让你可以取消收入限制，可以进行信号交易和在真实账户上进行交易。激活包括步骤，必须在结束前完成。',
        step1: {
            title: '步骤1、通过 OlympBot 系统注册 OlympTrade 账户。',
            text1: '要激活机器人，你需要用下面的表格注册 OlympTrade 账户:',
            text2: '不能用以前注册的账户激活机器人。',
            button: '显示注册表格'
        },
        step2: {
            title: '步骤2、存入100 美元或欧元以上',
            text1: '存入 100 美元或欧元以上。',
            text2: '存入金额由机器人使用的策略决定:在交易失败的情况下，必须有保证金。',
            button: '存款'
        },
        already: {
            title: '你的 OlympBot 已经被激活了',
            info: '您已经完成激活，可以使用机器人的所有功能了。'
        }
    },
    alert: {
        stop_user: '你取消了一个机器人赌注',
        filter_balance: '达到最大平衡过滤器(额外选项)',
        robot_start: '机器人正在运行',
        robot_start_info: '您可以使用平台将选项卡最小化。',
        robot_start_filter1: '一旦平衡达到，机器人就会停止',
        robot_start_filter2: '激活机器人以取消收入限制，或者重新启动它。',
        robot_stop: '机器人停止了'
    },
    process: {
        signal_search: '信号搜索',
        signal_search_info: '正在进行信号搜索...',
        current: '当前赌注',
        show: '显示'
    }
};

var lang_vi = {
    code: 'vi',
    top: {
        button: {
            open: 'Mở robot',
            close: 'Đóng robot'
        }
    },
    body: {
        change_acc: {
            title: 'Lựa chọn tài khoản',
            real_acc: 'Tài khoản thực',
            demo_acc: 'Tài khoản ảo',
            faq: {
                info: 'Chọn một tài khoản mà robot sẽ giao dịch.',
                warn: 'Giao dịch với robot trên tài khoản thật chỉ khả dụng sau khi kích hoạt.'
            }
        },
        start_robot: {
            title: 'Khởi động robot',
            button: 'Bắt đầu giao dịch'
        },
        stop_robot: {
            title: 'Dừng robot',
            button: 'Ngừng giao dịch'
        },
        main_param: {
            title: 'Tùy chọn giao dịch',
            amount: 'Số tiền ban đầu',
            time: 'Thời gian',
            asset: 'Tài sản giao dịch',
            times: {
                min1: '1 phút',
                min1_tag: 'min1',
                min5: '5 phút',
                min5_tag: 'min5',
                min10: '10 phút',
                min10_tag: 'min10',
                min15: '15 phút',
                min15_tag: 'min15'
            },
            faq: {
                amount_info: 'Số tiền giao dịch mà robot sẽ bắt đầu giao dịch ở mỗi vòng.',
                amount_rec: 'Giá trị đề xuất là 1$/€.',
                time_info: 'Thời gian giao dịch.',
                time_rec: 'Giá trị đề xuất là 1 phút.',
                asset_info: 'Tài sản mà robot sẽ giao dịch.',
                asset_rec: 'Tài sản được đề xuất là tài sản có tỷ lệ chiến thắng cao (&gt;70%).'
            }
        },
        strategy: {
            title: 'Chiến lược giao dịch',
            str1: 'Thắng mọi vòng (Tối ưu)',
            str2: 'Thắng mọi lần cược (Tấn công)',
            faq: {
                str1_info: 'Khi thắng lần cược tiếp theo, robot giao dịch với số tiền bằng với số tiền cược ban đầu. Nếu không, số tiền cược tiếp theo được tính toán để số tiền thắng bù lại tất cả số tiền thua trước đó và kiếm được số tiền bằng với tiền thắng từ lần đặt cược ban đầu.',
                str1_rec: 'Chiến lược được đề xuất cho số dư tài khoản từ 100 đến 1.000 đô la hoặc euro.',
                str2_info: 'Khi thắng lần cược tiếp theo, robot giao dịch với số tiền bằng với số tiền cược ban đầu. Nếu không, số tiền cược tiếp theo được tính toán sao cho số tiền thắng bù lại tất cả số tiền thua trước đó và kiếm được số tiền bằng với tiền thắng từ mỗi lần đặt cược.',
                str2_rec: 'Chiến lược được đề xuất cho số dư tài khoản là 1.000 đô la hoặc euro.'
            }
        },
        signals: {
            title: 'Giao dịch theo tín hiệu',
            check: 'Theo dõi tín hiệu giao dịch',
            faq: {
                title: 'Sử dụng tín hiệu từ máy chủ phân tích OlympBot',
                info: 'Với tính năng này, robot sẽ nhận được tín hiệu từ máy chủ phân tích của chúng tôi.',
                rec: 'Nên kích hoạt tùy chọn này. Tính năng này cải thiện độ chính xác của tỷ lệ lên đến 50%.',
                warn: 'Giao dịch theo tín hiệu chỉ khả dụng sau khi kích hoạt tài khoản. Bạn có thể kích hoạt tài khoản của mình và thử giao dịch theo tín hiệu trên tài khoản demo. Điều này được thực hiện để giảm tải cho máy chủ OlympBot.'
            }
        },
        signals_plus: {
            title: 'Giao dịch theo tín hiệu',
            button: 'Theo dõi tín hiệu giao dịch',
            text: 'Tăng độ chính xác đặt cược lên tới 50%'
        },
        add_param: {
            title: 'Tùy chọn bổ sung',
            balance: 'Số dư tài khoản tối đa',
            auto: 'Tự động lựa chọn tài sản',
            faq: {
                balance_info: 'Số dư tài khoản mà robot sẽ dừng công việc khi đạt được số dư đó.',
                balance_warn: 'Nếu không kích hoạt, robot sẽ dừng ngay khi kiếm được 20$/€. Bạn có thể bắt đầu robot lại hoặc thực hiện kích hoạt để loại bỏ hạn chế này.',
                auto_info: 'Robot sẽ tự động chọn tài sản sinh lãi cao nhất.',
                auto_rec: 'Nên kích hoạt tùy chọn này.'
            }
        },
        real_activate: {
            title: 'Giao dịch trên tài khoản trực tiếp',
            activate_text: 'Để giao dịch trên tài khoản trực tiếp, cần phải kích hoạt robot.',
            activate_button: 'Kích hoạt robot',
            demo_text: 'Nếu không kích hoạt, bạn có thể thử robot trên tài khoản demo.',
            demo_button: 'Chuyển đến tài khoản demo'
        },
        faq_button: 'Hướng dẫn',
        faq_title: 'Hướng dẫn về robot',
        buttons: {
            close: 'Đóng',
            ok: 'OK'
        }
    },
    activate: {
        title: 'Kích hoạt robot',
        info: 'Việc kích hoạt cho phép bạn loại bỏ giới hạn thu nhập, mở ra khả năng giao dịch theo tín hiệu và tài khoản thực. Việc kích hoạt bao gồm phải hoàn thành 2 bước.',
        step1: {
            title: 'Bước 1. Đăng ký tài khoản OlympTrade thông qua hệ thống OlympBot.',
            text1: 'Để kích hoạt robot, bạn cần phải có tài khoản OlympTrade được đăng ký theo biểu mẫu dưới đây:',
            text2: 'Không thể kích hoạt robot trên tài khoản đã đăng ký trước đó.',
            button: 'Hiển thị mẫu đăng ký'
        },
        step2: {
            title: 'Bước 2. Nạp tiền từ 100$/€ trở lên',
            text1: 'Nạp tiền từ 100$/€ trở lên.',
            text2: 'Số tiền nạp được xác định bởi chiến lược mà robot sử dụng: cần có một số tiền dự trữ để chi trả trong trường hợp giao dịch thất bại.',
            button: 'Gửi tiền'
        },
        already: {
            title: 'OlympBot của bạn đã được kích hoạt',
            info: 'Bạn đã hoàn thành các điều kiện kích hoạt và có thể sử dụng tất cả các chức năng của robot.'
        }
    },
    alert: {
        stop_user: 'Bạn đã hủy đặt cược robot',
        filter_balance: 'Đã đạt đến bộ lọc số dư tài khoản tối đa (Tùy chọn bổ sung)',
        robot_start: 'Robot đang chạy',
        robot_start_info: 'Bạn có thể thu nhỏ tab với nền tảng.',
        robot_start_filter1: 'Robot sẽ dừng lại ngay khi số dư là',
        robot_start_filter2: 'Kích hoạt robot để loại bỏ giới hạn thu nhập, hoặc khởi chạy lại robot.',
        robot_stop: 'Robot đã dừng'
    },
    process: {
        signal_search: 'Tìm kiếm tín hiệu',
        signal_search_info: 'Đang tìm kiếm tín hiệu ...',
        current: 'Tiền cược hiện tại',
        show: 'Hiển thị'
    }
};

var lang_ms = {
    code: 'ms',
    top: {
        button: {
            open: 'Buka robot',
            close: 'Tutup robot'
        }
    },
    body: {
        change_acc: {
            title: 'Pemilihan akaun',
            real_acc: 'Akaun sebenar',
            demo_acc: 'Akaun demo',
            faq: {
                info: 'Pilih akaun di mana robot akan berdagang.',
                warn: 'Dagangan dengan robot pada akuan sebenar tersedia hanya selepas pengaktifannya.'
            }
        },
        start_robot: {
            title: 'Mulakan robot',
            button: 'Mulakan dagangan'
        },
        stop_robot: {
            title: 'Hentikan robot',
            button: 'Hentikan dagangan'
        },
        main_param: {
            title: 'Pilihan dagangan',
            amount: 'Amaun permulaan',
            time: 'Masa',
            asset: 'Aset dagangan',
            times: {
                min1: '1 min',
                min1_tag: 'min1',
                min5: '5 min',
                min5_tag: 'min5',
                min10: '10 min',
                min10_tag: 'min10',
                min15: '15 min',
                min15_tag: 'min15'
            },
            faq: {
                amount_info: 'Amaun dagangan di mana robot akan mula berdagang setiap pusingan.',
                amount_rec: 'Nilai yang disarankan ialah $/€ 1.',
                time_info: 'Tempoh dagangan.',
                time_rec: 'Nilai yang disarankan ialah 1 min.',
                asset_info: 'Aset di mana robot akan berdagang.',
                asset_rec: 'Aset yang disarankan ialah aset dengan peratus kejayaan yang tinggi (&gt;70%).'
            }
        },
        strategy: {
            title: 'Strategi dagangan',
            str1: 'Berjaya setiap pusingan (Optimum)',
            str2: 'Berjaya setiap pertaruhan (Agresif)',
            faq: {
                str1_info: 'Apabila berjaya pertaruhan seterusnya, robot akan mengandaikan sama dengan pertaruhan permulaan. Jika tidak pertaruhan berikutnya dikira supaya amaun kejayaan menampung semua kerugian terdahulu dan menjana amaun sama dengan kejayaan daripada pertaruhan permulaan.',
                str1_rec: 'Strategi yang disarankan dengan baki 100 hingga 1000 dolar atau euro.',
                str2_info: 'Apabila memenangi pertaruhan seterusnya, robot akan mengandaikan sama dengan pertaruhan permulaan. Jika tidak pertaruhan berikutnya dikira dalam cara di mana amaun kejayaan menampung kerugian terdahulu dan menjana amaun sama dengan kejayaan daripada setiap pertaruhan.',
                str2_rec: 'Strategi tersebut disarankan untuk baki 1000 dolar atau euro.'
            }
        },
        signals: {
            title: 'Dagangan isyarat',
            check: 'Ikuti isyarat dagangan',
            faq: {
                title: 'Gunakan isyarat dari pelayan analitik OlympBot',
                info: 'Dengan ciri ini, robot akan menerima isyarat dari pelayan analitik kami.',
                rec: 'Disarankan untuk mendayakan pilihan ini. Ia meningkatkan ketepatan kadar sehingga 50%.',
                warn: 'Dagangan isyarat tersedia hanya selepas pengaktifan akaun. Anda boleh mengaktifkan akaun anda dan menguji dagangan pada isyarat di akaun demo. Ini dilakukan bagi mengurangkan muatan pada pelayan OlympBot.'
            }
        },
        signals_plus: {
            title: 'Dagangan isyarat',
            button: 'Ikuti isyarat dagangan',
            text: 'Meningkatkan ketepatan pertaruhan sehingga 50%'
        },
        add_param: {
            title: 'Pilihan tambahan',
            balance: 'Baki maks',
            auto: 'Pemilihan automatik aset',
            faq: {
                balance_info: 'Baki di mana robot akan menghentikan kerjanya.',
                balance_warn: 'Tanpa pengaktifan, robot akan berhenti sebaik sahaja ia menjana $/€ 20. Anda boleh memulakannya sekali lagi, atau meneruskan melalui pengaktifan dan membuang sekatan ini.',
                auto_info: 'Robot akan memilih aset paling menguntungkan secara automatik.',
                auto_rec: 'Disarankan untuk mendayakan pilihan ini.'
            }
        },
        real_activate: {
            title: 'Dagangan pada akaun hidup',
            activate_text: 'Bagi dagangan pada akaun hidup, pengaktifan robot diperlukan.',
            activate_button: 'Aktifkan robot',
            demo_text: 'Tanpa pengaktifan, anda boleh menguji robot pada akaun demo.',
            demo_button: 'Pergi ke akaun demo'
        },
        faq_button: 'Arahan',
        faq_title: 'Arahan robot',
        buttons: {
            close: 'Tutup',
            ok: 'OK'
        }
    },
    activate: {
        title: 'Pengaktifan robot',
        info: 'Pengaktifan membenarkan anda untuk membuang had pada pendapatan, membuka kemungkinan dagangan pada isyarat dan akaun sebenar. Pengaktifan terdiri daripada 2 langkah yang mesti dilengkapkan separuh jalan.',
        step1: {
            title: 'Langkah 1. Daftar akaun OlympTrade melalui sistem OlympBot.',
            text1: 'Untuk mengaktifkan robot, anda perlu memiliki akaun OlympTrade yang didaftarkan oleh borang di bawah:',
            text2: 'Mustahil untuk mengaktifkan robot pada akaun yang didaftarkan terlebih dahulu.',
            button: 'Tunjukkan borang pendaftaran'
        },
        step2: {
            title: 'Langkah 2. Deposit $/€ 100 atau lebih',
            text1: 'Deposit $/€ 100 atau lebih.',
            text2: 'Amaun deposit ditentukan oleh strategi yang digunakan dalam robot: perlu untuk memiliki margin untuk menampung sekiranya transaksi gagal.',
            button: 'Deposit'
        },
        already: {
            title: 'OlympBot anda telah diaktifkan',
            info: 'Anda telah melengkapkan syarat-syarat pengaktifan dan boleh menggunakan semua fungsi robot.'
        }
    },
    alert: {
        stop_user: 'Anda membatalkan pertaruhan robot',
        filter_balance: 'Penapis baki maksimum dicapai (Pilihan tambahan)',
        robot_start: 'Robot sedang beroperasi',
        robot_start_info: 'Anda boleh mengurangkan tab dengan platform.',
        robot_start_filter1: 'Robot akan berhenti sebaik sahaja baki',
        robot_start_filter2: 'Aktifkan robot untuk membuang had pendapatan, atau lancarkannya semula.',
        robot_stop: 'Robot berhenti'
    },
    process: {
        signal_search: 'Carian isyarat',
        signal_search_info: 'Carian isyarat sedang berlangsung ...',
        current: 'Pertaruhan semasa',
        show: 'Tunjuk'
    }
};

var lang_pt = {
    code: 'pt',
    top: {
        button: {
            open: 'Abrir o robô',
            close: 'Fechar o robô'
        }
    },
    body: {
        change_acc: {
            title: 'Seleção de conta',
            real_acc: 'Conta real',
            demo_acc: 'Conta demo',
            faq: {
                info: 'Selecione uma conta em que o robô irá operar.',
                warn: 'É possível operar com um robô em uma conta real somente após sua ativação.'
            }
        },
        start_robot: {
            title: 'Iniciar o robô',
            button: 'Começar a operar'
        },
        stop_robot: {
            title: 'Parar o robô',
            button: 'Parar de operar'
        },
        main_param: {
            title: 'Opções de operação',
            amount: 'Quantia inicial',
            time: 'Tempo',
            asset: 'Ativos',
            times: {
                min1: '1 min.',
                min1_tag: 'min1',
                min5: '5 min.',
                min5_tag: 'min5',
                min10: '10 min.',
                min10_tag: 'min10',
                min15: '15 min.',
                min15_tag: 'min15'
            },
            faq: {
                amount_info: 'A quantia de operação que o robô irá operar a cada ciclo.',
                amount_rec: 'O valor recomendado é $/€ 1.',
                time_info: 'O período de operação.',
                time_rec: 'O valor recomendado é 1 min.',
                asset_info: 'O ativo que o robô irá operar.',
                asset_rec: 'O ativo recomendado é aquele com uma porcentagem alta de ganho (&gt;70%).'
            }
        },
        strategy: {
            title: 'Estratégias de operação',
            str1: 'Ganhar toda rodada (Ideal)',
            str2: 'Ganhar toda aposta (Agressivo)',
            faq: {
                str1_info: 'Ao ganhar a próxima aposta, o robô assume igual à aposta inicial. Senão, apostas subsequentes são calculadas para que a quantia ganha cubra todas as perdas anteriores e obtenham um valor igual ao ganho da aposta inicial.',
                str1_rec: 'Estratégia recomendada com um saldo de 100 a 1000 dólares ou euros.',
                str2_info: 'Ao ganhar a próxima aposta, o robô assume igual à aposta inicial. Senão, apostas subsequentes são calculadas de forma que a quantia ganha cubra todas as perdas anteriores e obtenham um valor igual ao ganho de cada aposta.',
                str2_rec: 'A estratégia é recomendada para um saldo de 1000 dólares ou euros.'
            }
        },
        signals: {
            title: 'Operação baseada em sinais',
            check: 'Seguir sinais de operação',
            faq: {
                title: 'Use sinais do servidor de análises OlympBot',
                info: 'Com esse recurso, o robô receberá automaticamente sinais de nosso servidor de análise.',
                rec: 'É recomendável habilitar essa opção. Ela melhora a precisão de taxas em até 50%.',
                warn: 'A operação baseada em sinais está disponível somente após a ativação da conta. Você pode ativar sua conta e testar a operação baseada em sinais em uma conta de demonstração. Isso é feito para reduzir a carga sobre o servidor OlympBot.'
            }
        },
        signals_plus: {
            title: 'Operação baseada em sinais',
            button: 'Seguir sinais de operação',
            text: 'Aumenta a precisão de aposta em até 50%'
        },
        add_param: {
            title: 'Opções extras',
            balance: 'Saldo máximo',
            auto: 'Autosseleção de ativo',
            faq: {
                balance_info: 'Saldo em que o robô encerra seu trabalho.',
                balance_warn: 'Sem ativação, o robô irá parar assim que ganhar $/€ 20. Você pode reiniciá-lo, ou completar a ativação e remover essa restrição.',
                auto_info: 'O robô selecionará o ativo mais rentável automaticamente.',
                auto_rec: 'É recomendável ativar essa opção.'
            }
        },
        real_activate: {
            title: 'Operar em uma conta real',
            activate_text: 'Para operar em uma conta real, é necessária a ativação do robô.',
            activate_button: 'Ativar o robô',
            demo_text: 'Sem ativação, você pode testar o robô em uma conta de demonstração.',
            demo_button: 'Ir para a conta de demonstração'
        },
        faq_button: 'Instrução',
        faq_title: 'Instrução do robô',
        buttons: {
            close: 'Fechar',
            ok: 'OK'
        }
    },
    activate: {
        title: 'Ativação do robô',
        info: 'A ativação permite-lhe remover o limite de ganhos, e abre a possibilidade de operação baseada em sinais e em uma conta real. A ativação consiste em 2 etapas que precisam ser concluídas.',
        step1: {
            title: 'Passo 1. Crie uma conta OlympTrade por meio do sistema OlympBot.',
            text1: 'Para ativar o robô, você precisa ter uma conta OlympTrade criada pelo formulário abaixo:',
            text2: 'É impossível ativar o robô em uma conta previamente criada.',
            button: 'Mostrar formulário de inscrição'
        },
        step2: {
            title: 'Passo 2. Depositar $/€ 100 (R$400) ou mais',
            text1: 'Deposite $/€100 (R$400) ou mais',
            text2: 'O montante do depósito é determinado pela estratégia usada no robô: é necessário ter uma margem para cobertura em caso de uma transação com falha.',
            button: 'Depósito'
        },
        already: {
            title: 'Seu OlympBot já está ativado',
            info: 'Você preencheu as condições de ativação e agora pode usar todas as funcionalidades do robô.'
        }
    },
    alert: {
        stop_user: 'Você cancelou uma aposta do robô',
        filter_balance: 'Filtro de saldo máximo atingido (Opções extras)',
        robot_start: 'O robô está em execução',
        robot_start_info: 'Você pode minimizar a aba com a plataforma.',
        robot_start_filter1: 'O robô irá parar assim que o saldo for ',
        robot_start_filter2: 'Ative o robô para remover a restrição de receita, ou reinicie-o.',
        robot_stop: 'Robô parado'
    },
    process: {
        signal_search: 'Pesquisa de sinais',
        signal_search_info: 'Pesquisa de sinais em andamento...',
        current: 'Aposta atual',
        show: 'Mostrar'
    }
};

var lang_th = {
    code: 'th',
    top: {
        button: {
            open: 'เปิดหุ่นยนต์',
            close: 'ปิดหุ่นยนต์'
        }
    },
    body: {
        change_acc: {
            title: 'การเลือกบัญชี',
            real_acc: 'บัญชีจริง',
            demo_acc: 'บัญชีฝึกหัด',
            faq: {
                info: 'เลือกบัญชีที่จะให้หุ่นยนต์ซื้อขาย',
                warn: 'การซื้อขายกับหุ่นยนต์ในบัญชีจริงจะพร้อมใช้งานหลังเปิดใช้งานเท่านั้น'
            }
        },
        start_robot: {
            title: 'เริ่มหุ่นยนต์',
            button: 'เริ่มซื้อขาย'
        },
        stop_robot: {
            title: 'หยุดหุ่นยนต์',
            button: 'หยุดซื้อขาย'
        },
        main_param: {
            title: 'ตัวเลือกการซื้อขาย',
            amount: 'ยอดเริ่มต้น',
            time: 'เวลา',
            asset: 'สินทรัพย์ซื้อขาย',
            times: {
                min1: '1 นาที',
                min1_tag: 'min1',
                min5: '5 นาที',
                min5_tag: 'min5',
                min10: '10 นาที',
                min10_tag: 'min10',
                min15: '15 นาที',
                min15_tag: 'min15'
            },
            faq: {
                amount_info: 'ยอดซื้อขายที่หุ่นยนต์จะเริ่มซื้อขายในแต่ละรอบ',
                amount_rec: 'ค่าที่แนะนำคือ $/€ 1',
                time_info: 'ระยะเวลาซื้อขาย',
                time_rec: 'ค่าที่แนะนำคือ 1 นาที',
                asset_info: 'ทรัพย์สินที่หุ่นยนต์จะซื้อขาย',
                asset_rec: 'ทรัพย์สินที่แนะนำคือทรัพย์สินที่มีค่าร้อยละที่จะชนะสูง (&gt;70%)'
            }
        },
        strategy: {
            title: 'กลยุทธ์การซื้อขาย',
            str1: 'ชนะทุกรอบ (เหมาะสมที่สุด)',
            str2: 'ชนะทุกเดิมพัน (เชิงรุก)',
            faq: {
                str1_info: 'เมื่อชนะเดิมพันถัดไป หุ่นยนต์จะอนุมานเท่ากับเงินเดิมพันเริ่มต้น ไม่เช่นนั้นจะมีการคำนวณเงินเดิมพันครั้งถัดๆ มาเพื่อให้ปริมาณที่ชนะชดเชยปริมาณที่เสียไปก่อนหน้านั้นและได้ยอดเท่ากับที่ชนะจากเงินเดิมพันเริ่มต้น',
                str1_rec: 'กลยุทธ์ที่แนะนำสำหรับยอดคงเหลือ 100 ถึง 1000 ดอลลาร์หรือยูโร',
                str2_info: 'เมื่อชนะเดิมพันถัดไป หุ่นยนต์จะอนุมานเท่ากับเงินเดิมพันเริ่มต้น ไม่เช่นนั้นจะมีการคำนวณเงินเดิมพันครั้งถัดๆ มาในลักษณะที่ปริมาณที่ชนะชดเชยปริมาณที่เสียไปก่อนหน้านั้นและได้ยอดเท่ากับที่ชนะจากการเดิมพันแต่ละครั้ง',
                str2_rec: 'แนะนำกลยุทธ์นี้สำหรับยอดคงเหลือ 1000 ดอลลาร์หรือยูโร'
            }
        },
        signals: {
            title: 'การซื้อขายตามสัญญาณ',
            check: 'ทำตามสัญญาณการซื้อขาย',
            faq: {
                title: 'ใช้สัญญาณจากเซิร์ฟเวอร์วิเคราะห์ OlympBot',
                info: 'คุณลักษณะนี้จะทำให้หุ่นยนต์รับสัญญาณจากเซิร์ฟเวอร์วิเคราะห์ของเรา',
                rec: 'แนะนำให้เปิดใช้งานตัวเลือกนี้ ซึ่งจะเสริมความแม่นยำของอัตราต่างๆ ได้สูงสุดถึง 50%',
                warn: 'การซื้อขายตามสัญญาณจะพร้อมใช้งานหลังเปิดใช้งานบัญชีเท่านั้น คุณสามารถเปิดใช้งานบัญชีของคุณแล้วทดสอบซื้อขายตามสัญญาณในบัญชีสาธิตได้ ที่เป็นเช่นนี้เพื่อให้ลดภาระที่เครื่องเซิร์ฟเวอร์ OlympBot'
            }
        },
        signals_plus: {
            title: 'การซื้อขายตามสัญญาณ',
            button: 'ทำตามสัญญาณการซื้อขาย',
            text: 'เพิ่มความแม่นยำของเดิมพันสูงสุดถึง 50%'
        },
        add_param: {
            title: 'ตัวเลือกเพิ่มเติม',
            balance: 'ยอดคงเหลือสูงสุด',
            auto: 'การเลือกทรัพย์สินอัตโนมัติ',
            faq: {
                balance_info: 'ยอดคงเหลือที่หุ่นยนต์จะหยุดการทำงาน',
                balance_warn: 'หากไม่เปิดใช้งาน หุ่นยนต์จะหยุดทันทีที่ได้ $/€ 20 คุณสามารถเริ่มหุ่นยนต์อีกครั้งหรือเปิดใช้งานแล้วลบข้อจำกัดนี้ออกไปก็ได้',
                auto_info: 'หุ่นยนต์จะเลือกทรัพย์สินที่ให้ผลกำไรมากที่สุดโดยอัตโนมัติ',
                auto_rec: 'แนะนำให้เปิดใช้งานตัวเลือกนี้'
            }
        },
        real_activate: {
            title: 'การซื้อขายในบัญชีสด',
            activate_text: 'ต้องเปิดใช้งานหุ่นยนต์จึงจะดำเนินการซื้อขายในบัญชีสดได้',
            activate_button: 'เปิดใช้งานหุ่นยนต์',
            demo_text: 'หากไม่เปิดใช้งาน คุณจะสามารถทดสอบหุ่นยนต์ได้ในบัญชีสาธิต',
            demo_button: 'ไปที่บัญชีสาธิต'
        },
        faq_button: 'คำแนะนำ',
        faq_title: 'คำสั่งของหุ่นยนต์',
        buttons: {
            close: 'ปิด',
            ok: 'ตกลง'
        }
    },
    activate: {
        title: 'การเปิดใช้งานหุ่นยนต์',
        info: 'การเปิดใช้งานจะทำให้คุณสามารถลบวงเงินได้ออก ทำให้มีโอกาสซื้อขายตามสัญญาณและในบัญชีจริง การเปิดใช้งานประกอบไปด้วยขั้นตอน 2 ขั้นที่ต้องทำระหว่างดำเนินการ',
        step1: {
            title: 'ขั้นตอนที่ 1. ลงทะเบียนบัญชี Olymp Trade ผ่านระบบ OlympBot',
            text1: 'หากต้องการเปิดใช้งานหุ่นยนต์ คุณจะต้องมีบัญชี OlympTrade ที่ลงทะเบียนโดยแบบฟอร์มด้านล่าง:',
            text2: 'บัญชีที่ลงทะเบียนแล้วจะไม่สามารถเปิดใช้งานหุ่นยนต์ได้',
            button: 'แสดงแบบฟอร์มลงทะเบียน'
        },
        step2: {
            title: 'ขั้นตอนที่ 2. ฝาก $/€ 100 ขึ้นไป',
            text1: 'ฝาก $/€ 100 ขึ้นไป',
            text2: 'กลยุทธ์ที่ใช้ในหุ่นยนต์จะเป็นสิ่งกำหนดยอดฝาก: การมีหลักประกันเพื่อชดเชยในกรณีที่ธุรกรรมล้มเหลวเป็นสิ่งที่จำเป็น',
            button: 'ฝากเงิน'
        },
        already: {
            title: 'OlympBot ของคุณเปิดใช้งานอยู่แล้ว',
            info: 'คุณได้ทำตามเงื่อนไขการเปิดใช้งานแล้ว และสามารถใช้ฟังก์ชันการทำงานทั้งหมดของหุ่นยนต์ได้'
        }
    },
    alert: {
        stop_user: 'คุณยกเลิกการเดิมพันของหุ่นยนต์',
        filter_balance: 'ถึงตัวกรองยอดคงเหลือสูงสุดแล้ว (ตัวเลือกเพิ่มเติม)',
        robot_start: 'หุ่นยนต์กำลังทำงานอยู่',
        robot_start_info: 'คุณสามารถย่อแท็บลงด้วยแพลตฟอร์มได้',
        robot_start_filter1: 'หุ่นยนต์จะหยุดทันทีที่ยอดคงเหลือเป็น',
        robot_start_filter2: 'เปิดใช้งานหุ่นยนต์เพื่อลบขีดวงเงินได้หรือเริ่มต้นเปิดใช้อีกครั้ง',
        robot_stop: 'หุ่นยนต์หยุดทำงานแล้ว'
    },
    process: {
        signal_search: 'ค้นหาสัญญาณ',
        signal_search_info: 'อยู่ระหว่างค้นหาสัญญาณ ...',
        current: 'เงินเดิมพันปัจจุบัน',
        show: 'แสดง'
    }
};

var lang_hi = {
    code: 'hi',
    top: {
        button: {
            open: 'रोबोट को खोलें',
            close: 'रोबोट को बंद करें'
        }
    },
    body: {
        change_acc: {
            title: 'खाते का चयन',
            real_acc: 'लाइव खाता',
            demo_acc: 'डेमो खाता',
            faq: {
                info: 'एक खाते का चयन करें जिससे रोबोट व्यापार करेगा।',
                warn: 'वास्तविक खाते से रोबोट के साथ व्यापार इसकी सक्रियता के बाद ही उपलब्ध है।'
            }
        },
        start_robot: {
            title: 'रोबोट को शुरू करें',
            button: 'व्यापार शुरू करें'
        },
        stop_robot: {
            title: 'रोबोट को रोकें',
            button: 'व्यापार रोकें'
        },
        main_param: {
            title: 'व्यापार के विकल्प',
            amount: 'प्रारंभिक राशि',
            time: 'समय',
            asset: 'व्यापर की संपत्ति',
            times: {
                min1: '1 min',
                min1_tag: 'min1',
                min5: '5 min',
                min5_tag: 'min5',
                min10: '10 min',
                min10_tag: 'min10',
                min15: '15 min',
                min15_tag: 'min15'
            },
            faq: {
                amount_info: 'व्यापार की राशि जिससे रोबोट प्रत्येक भाग में व्यापार करना शुरू करेगा।',
                amount_rec: 'अनुशंसित राशि $/€ 1 है।',
                time_info: 'व्यापार की अवधि।',
                time_rec: 'अनुशंसित मूल्य 1 मिनट है।',
                asset_info: 'वह संपत्ति जिससे रोबोट व्यापार करेगा।',
                asset_rec: 'अनुशंसित संपत्ति वह है जिसकी जीत का प्रतिशत (&gt;70%) अधिक है।'
            }
        },
        strategy: {
            title: 'व्यापर की रणनीतियाँ',
            str1: 'हर दौर जीतें (वैकल्पिक)',
            str2: 'हर दाँव जीतें (आक्रामक)',
            faq: {
                str1_info: 'अगली शर्त जीतने पर, रोबोट प्रारंभिक शर्त के बराबर प्राप्त करता है। अन्यथा पिछले दाँव की गणना की जाती है जिससे जीत की राशि पिछले सभी नुकसानों को सुरक्षित करे और शुरुआती दाँव से जीत के बराबर की राशि अर्जित करे।',
                str1_rec: '100 से 1000 डॉलर या यूरो की शेष राशि के साथ अनुशंसित रणनीति।',
                str2_info: 'अगली शर्त जीतने पर, रोबोट प्रारंभिक शर्त के बराबर प्राप्त करता है। अन्यथा पिछले दाँव की गणना इस तरह की जाती है कि जीत की राशि पिछले सभी हार को सुरक्षित करे और प्रत्येक शर्त से जीत के बराबर की राशि अर्जित करें।',
                str2_rec: 'यह रणनीति 1000 डॉलर या यूरो की शेष राशि के लिए अनुशंसित है।'
            }
        },
        signals: {
            title: 'संकेत व्यापार',
            check: 'व्यापार संकेतों का पालन करें',
            faq: {
                title: 'विश्लेषक सर्वर OlympBot के संकेतों का उपयोग करें',
                info: 'इस सुविधा से, रोबोट हमारे विश्लेषक सर्वर से संकेत प्राप्त करेगा।',
                rec: 'इस विकल्प को सक्रिय करना अनुशंसित है। यह दरों की सटीकता को 50% तक बढ़ाता है।',
                warn: 'सिग्नल व्यापार खाता सक्रिय होने के बाद ही उपलब्ध होता है। आप डेमो खाते से अपना खाता सक्रिय करके संकेतों से व्यापार का परीक्षण कर सकते हैं। यह OlympBot सर्वर पर दबाव कम करने के लिए किया जाता है।'
            }
        },
        signals_plus: {
            title: 'संकेत व्यापार',
            button: 'व्यापार संकेतों का पालन करें',
            text: 'दाँव की सटीकता तो ५०% तक बढ़ाऐं'
        },
        add_param: {
            title: 'अतिरिक्त विकल्प',
            balance: 'अधिकतम शेष राशि',
            auto: 'संपत्ति का स्वतः चयन',
            faq: {
                balance_info: 'शेष राशि जिस पर रोबोट अपना काम रोक देगा।',
                balance_warn: 'सक्रिय ना होने पर रोबोट $/€ 20 अर्जित करते ही रुक जाएगा। आप इसे पुनः शुरू कर सकते है, या सक्रिय करने के माध्यम से इस प्रतिबन्ध को हरा सहते हैं।',
                auto_info: 'रोबोट सबसे अधिक लाभदायक संपत्ति का चयन स्वयं करेगा।',
                auto_rec: 'इस विकल्प को सक्षम करना अनुशंसित है।'
            }
        },
        real_activate: {
            title: 'लाइव खाते से व्यापार',
            activate_text: 'लाइव खाते से व्यापार के लिए रोबोट को सक्रीय करना आवश्यक है।',
            activate_button: 'रोबोट को सक्रीय करें',
            demo_text: 'सक्रिय किए बिना, आप डेमो खाते से रोबोट का परिक्षण कर सकते हैं।',
            demo_button: 'डेमो खाते पर जाऐं'
        },
        faq_button: 'निर्देश',
        faq_title: 'रोबोट के निर्देश',
        buttons: {
            close: 'बंद',
            ok: 'ठीक है'
        }
    },
    activate: {
        title: 'रोबोट सक्रिय करना',
        info: 'सक्रियण आपको कमाई पर से सीमा हटाने, संकेतों से व्यापार की संभावना का निर्माण करने और वास्तविक खाते की अनुमति देता है। सक्रियण 2 भागों  से बना होता हैं जिन्हें आधे रस्ते में पूरा किया जाना चाहिए।',
        step1: {
            title: '1 भाग. OlympBot प्रणाली के माध्यम से Olymp व्यापार खाते का पंजीकरण करें।',
            text1: 'रोबोट को सक्रिय करने के लिए, आपके पास दिए गए फॉर्म के द्वारा एक पंजीकृत OlympTrade खाता होना चाहिए:',
            text2: 'पहले से पंजीकृत खाते से रोबोट को सक्रिय करना असंभव है।',
            button: 'पंजीकरण फॉर्म दिखाएं'
        },
        step2: {
            title: '2 भाग. $/€ 100 या अधिक जमा करें',
            text1: '$/€ 100 या अधिक जमा करें।',
            text2: 'जमा की जाने वाली राशि रोबोट में उपयोग की जाने वाली रणनीति द्वारा निर्धारित की जाती है: असफल लेनदेन के मामले में सुरक्षा के लिए मार्जिन होना आवश्यक है।',
            button: 'जमा करें'
        },
        already: {
            title: 'आपका OlympBot पहले से ही सक्रिय कर दिया गया है',
            info: 'आपने सक्रियता की शर्तों को पूरा कर लिया है और रोबोट की सारी कार्यक्षमता का उपयोग कर सकते हैं।'
        }
    },
    alert: {
        stop_user: 'आपने एक रोबोट दाँव रद्द कर दिया',
        filter_balance: 'अधिकतम शेष राशि फ़िल्टर तक पहुँच गए (अतिरिक्त विकल्प)',
        robot_start: 'रोबोट क्रियाशील है',
        robot_start_info: 'आप प्लेटफॉर्म से टैब को छोटा कर सकते हैं।',
        robot_start_filter1: 'शेष राशि होते ही रोबोट रुक जाएगा',
        robot_start_filter2: 'आय की सीमा हटाने के लिए रोबोट को सक्रिय करें, या इसे फिर से लॉन्च करें।',
        robot_stop: 'रोबोट रुक गया'
    },
    process: {
        signal_search: 'संकेत की खोज',
        signal_search_info: 'संकेत की खोज जारी है ...',
        current: 'वर्तमान दाँव',
        show: 'दिखाऐं'
    }
};

var lang_ar = {
    code: 'ar',
    top: {
        button: {
            open: 'افتح الروبوت',
            close: 'أغلق الروبوت'
        }
    },
    body: {
        change_acc: {
            title: 'اختيار الحساب',
            real_acc: 'الحساب الحقيقي',
            demo_acc: 'حساب تجريبي',
            faq: {
                info: 'اختيار حساب يتداول عليه الروبوت.',
                warn: 'لا يتوفر التداول باستخدام روبوت على حساب حقيقي إلا بعد تفعيله.'
            }
        },
        start_robot: {
            title: 'ابدأ تشغيل الروبوت',
            button: 'ابدأ التداول'
        },
        stop_robot: {
            title: 'أوقف تشغيل الروبوت',
            button: 'أوقف التداول'
        },
        main_param: {
            title: 'خيارات التداول',
            amount: 'المبلغ الأولي',
            time: 'الوقت',
            asset: 'تداول الأصول',
            times: {
                min1: '1 min',
                min1_tag: 'min1',
                min5: '5 min',
                min5_tag: 'min5',
                min10: '10 min',
                min10_tag: 'min10',
                min15: '15 min',
                min15_tag: 'min15'
            },
            faq: {
                amount_info: 'مبلغ التداول الذي يبدأ عنده الروبوت في التداول في كل دورة.',
                amount_rec: 'القيمة الموصى بها هي 1 $/€.',
                time_info: 'فترة التداول.',
                time_rec: 'القيمة الموصى بها هي 1 دقيقة.',
                asset_info: 'الأصل الذي سيستخدمه الروبوت في التداول.',
                asset_rec: 'الأصل الموصى به هو الأصل ذو نسبة الفوز العالية (&gt; 70٪).'
            }
        },
        strategy: {
            title: 'استراتيجيات التداول',
            str1: 'اربح كل جولة (الأمثل)',
            str2: 'اربح كل رهان (هجومي)',
            faq: {
                str1_info: 'عند الفوز بالرهان التالي ، يفترض أن الروبوت يساوي الرهان المبدئي. خلاف ذلك يتم احتساب الرهانات اللاحقة بحيث يغطي مبلغ الفوز جميع الخسائر السابقة ويكسب مبلغًا مساويًا للفوز من الرهان المبدئي.',
                str1_rec: 'الاستراتيجية الموصى بها برصيد 100 إلى 1000 دولار أو يورو.',
                str2_info: 'عند الفوز بالرهان التالي ، يفترض أن الروبوت يساوي الرهان المبدئي. خلاف ذلك يتم حساب الرهانات اللاحقة بطريقة تجعل مبلغ الفوز يغطي جميع الخسائر السابقة ويكسب مبلغاً مساوياً للفوز من كل رهان.',
                str2_rec: 'الاستراتيجية موصى بها لرصيد 1000 دولار أو يورو.'
            }
        },
        signals: {
            title: 'تداول الإشارات',
            check: 'متابعة إشارات التداول',
            faq: {
                title: 'استخدام الإشارات من خادم التحليلات OlympBot',
                info: 'باستخدام هذه الميزة ، سيتلقى الروبوت إشارات من خادم التحليلات.',
                rec: 'من المستحسن تمكين هذا الخيار. فهو يحسن دقة المعدلات بنسبة تصل إلى 50 ٪.',
                warn: 'تداول الإشارات متاح فقط بعد تفعيل الحساب. يمكنك تفعيل حسابك واختبار التداول على الإشارات في إحدى الحسابات التجريبية. يتم ذلك لتقليل الحمل على خادم OlympBot.'
            }
        },
        signals_plus: {
            title: 'تداول الإشارات',
            button: 'متابعة إشارات التداول',
            text: 'زيادة دقة الرهان حتى 50٪'
        },
        add_param: {
            title: 'خيارات إضافية',
            balance: 'أقصى رصيد',
            auto: 'الاختيار الآلي للأصول',
            faq: {
                balance_info: 'الرصيد الذي سيتوقف عنده الروبوت عن العمل.',
                balance_warn: 'بدون التفعيل، سيتوقف الروبوت بمجرد أن يكسب $ / € 20. يمكنك تشغيله مرة أخرى ، أو الانتقال للتفعيل وإزالة هذا القيد.',
                auto_info: 'سيقوم الروبوت بتحديد الأصول الأكثر ربحية تلقائياً.',
                auto_rec: 'من المستحسن تمكين هذا الخيار.'
            }
        },
        real_activate: {
            title: 'التداول على حساب حقيقي',
            activate_text: 'للتداول على حساب حقيقي ، يجب تفعيل الروبوت.',
            activate_button: 'تفعيل الروبوت',
            demo_text: 'بدون التفعيل، يمكنك اختبار الروبوت على حساب تجريبي.',
            demo_button: 'اذهب إلى الحساب التجريبي'
        },
        faq_button: 'تعليمات',
        faq_title: 'تعليمات الروبوت',
        buttons: {
            close: 'إغلاق',
            ok: 'حسناً'
        }
    },
    activate: {
        title: 'تفعيل الروبوت',
        info: 'يتيح لك التفعيل إزالة حد الأرباح ، وفتح إمكانية التداول على الإشارات والحساب الحقيقي. يتكون التفعيل من خطوتين يجب إكمالهما جزئياً.',
        step1: {
            title: 'الخطوة 1. تسجيل حساب Olymp Trade من خلال نظام OlympBot.',
            text1: 'لتفعيل الروبوت ، يجب أن يكون لديك حساب OlympTrade مسجل في النموذج أدناه:',
            text2: 'من المستحيل تفعيل الروبوت على حساب مسجل سابقًا.',
            button: 'عرض نموذج التسجيل'
        },
        step2: {
            title: 'الخطوة 2. إيداع 100 دولار / يورو أو أكثر',
            text1: 'إيداع $ / € 100 أو أكثر.',
            text2: 'يحدد مبلغ الإيداع بالاستراتيجية المستخدمة في الروبوت: من الضروري أن يكون لديك هامش للتغطية في حالة فشل العملية.',
            button: 'إجراء إيداع'
        },
        already: {
            title: 'تم تفعيل OlympBot ',
            info: 'لقد أكملت شروط التفعيل ويمكنك استخدام جميع وظائف الروبوت.'
        }
    },
    alert: {
        stop_user: 'لقد ألغيت رهان الروبوت',
        filter_balance: 'تم الوصول إلى الحد الأقصى لتصفية الرصيد (خيارات إضافية)',
        robot_start: 'الروبوت يعمل',
        robot_start_info: 'يمكنك تصغير علامة التبويب باستخدام النظام الأساسي.',
        robot_start_filter1: 'سوف يتوقف الروبوت بمجرد أن يكون الرصيد',
        robot_start_filter2: 'قم بتفعيل الروبوت لإزالة حد الدخل ، أو أعد تشغيله.',
        robot_stop: 'توقف الروبوت'
    },
    process: {
        signal_search: 'البحث عن إشارة',
        signal_search_info: 'جاري البحث عن إشارة ...',
        current: 'الرهان الحالي',
        show: 'عرض'
    }
};
